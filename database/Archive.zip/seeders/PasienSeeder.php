<?php

namespace Database\Seeders;

use App\Models\Pasien;
use Illuminate\Database\Seeder;

class PasienSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $pasien = [
            [
                'id_register' => '1202110001',
                'nama' => 'ipul',
                'tempat_lahir' => 'maros',
                'tanggal_lahir' => '2000-06-20',
                'jenis_kelamin' => 'laki-laki',
                'agama' => 'islam',
                'pekerjaan' => 'mahasiswa',
                'alamat' => 'jalan jendral sudirman maros',
                'status' => 'belum menikah',
                'jenis_pasien' => 'umum',
                'no_BPJS' => 'umum',
            ],
        ];
        foreach ($pasien as $key => $value) {
            Pasien::create($value);
        }
    }
}
