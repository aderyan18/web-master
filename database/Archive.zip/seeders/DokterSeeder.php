<?php

namespace Database\Seeders;

use App\Models\Dokter;
use Illuminate\Database\Seeder;

class DokterSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $user = [
            [
                'nip' => 'super admin',
                'nama' => 'super admin',
                'jenis_kelamin' => 'laki-laki',
                'spesialis' => 'super admin'
            ],
        ];
        foreach ($user as $key => $value) {
            Dokter::create($value);
        }
    }
}
